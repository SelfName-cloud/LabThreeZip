using NUnit.Framework;
using ��3;
using System.Collections.Generic;

namespace Tests
{
    public class Tests
    {
        Rational_numbers Numbers = new Rational_numbers();
      
        //Test for method Input_numbers
        [Test]
        public void Test_Input_numbers()
        {
            var input_numerator = 23;
            var input_denumerator = 34;
            var expect = "23/34";
            Assert.AreEqual(expect, Numbers.Input_numbers(input_numerator, input_denumerator));
            
           
        }
        [Test]
        public void Test_Input_numbers_zero_numerator()
        {
            var input_numerator = 0;
            var input_denumerator = 34;
            var expect = "0";
            Assert.AreEqual(expect, Numbers.Input_numbers(input_numerator, input_denumerator));


        }
        [Test]
        public void Test_Input_numbers_zero_denumerator()
        {
            var input_numerator = 23;
            var input_denumerator = 0;
            var expect = "0";
            Assert.AreEqual(expect, Numbers.Input_numbers(input_numerator, input_denumerator));


        }
        //Test for Evklid 

        [Test]
        public void Test_Evklid_numbers()
        {
            var numerator = 9;
            var denumerator = 10;
            var expect = 1;
            Assert.AreEqual(expect, Numbers.Evklid_number(numerator, denumerator));

        }
        [Test]
        public void Test_Evklid_numbers_bigint()
        {
            var numerator = 9000000;
            var denumerator = 3000000;
            var expect = 3000000;
            Assert.AreEqual(expect, Numbers.Evklid_number(numerator, denumerator));

        }
        [Test]
        public void Test_Evklid_numbers_minus()
        {
            var numerator = -15;
            var denumerator = -5;
            var expect = 5;
            Assert.AreEqual(expect, Numbers.Evklid_number(numerator, denumerator));

        }
        //Test for method Plus_fraction
        [Test]
        public void Test_Plus_franction()
        {
            var frac1 = "12/34";
            var frac2 = "23/45";
            var expect = "661/765";
            Assert.AreEqual(expect, Numbers.Plus_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Plus_franction_minus()
        {
            var frac1 = "-2/3";
            var frac2 = "3/4";
            var expect = "1/12";
            Assert.AreEqual(expect, Numbers.Plus_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Plus_franction_double_minus()
        {
            var frac1 = "-2/3";
            var frac2 = "-3/4";
            var expect = "-17/12";
            Assert.AreEqual(expect, Numbers.Plus_fraction(frac1, frac2));
        }
        //Test for method Minus_fraction
        [Test]
        public void Test_Minus_fraction()
        {
            var frac1 = "2/3";
            var frac2 = "3/4";
            var expect = "-1/12";
            Assert.AreEqual(expect, Numbers.Minus_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Minus_fraction_minus()
        {
            var frac1 = "21/32";
            var frac2 = "-3/16";
            var expect = "27/32";
            Assert.AreEqual(expect, Numbers.Minus_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Minus_fraction_double_minus()
        {
            var frac1 = "-2/32";
            var frac2 = "-3/32";
            var expect = "1/32";
            Assert.AreEqual(expect, Numbers.Minus_fraction(frac1, frac2));
        }
        //Test for method Multiply_fraction
        [Test]
        public void Test_Multiply_fraction_double_minus()
        {
            var frac1 = "-2/32";
            var frac2 = "-3/32";
            var expect = "3/512";
            Assert.AreEqual(expect, Numbers.Multiply_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Multiply_fraction()
        {
            var frac1 = "45/43";
            var frac2 = "3/9";
            var expect = "15/43";
            Assert.AreEqual(expect, Numbers.Multiply_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Multiply_fraction_zero_numerator()
        {
            var frac1 = "40/43";
            var frac2 = "3/0";
            var expect = "������� �� ����";
            Assert.AreEqual(expect, Numbers.Multiply_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Multiply_fraction_zero_denumerator()
        {
            var frac1 = "0/4";
            var frac2 = "3/9";
            var expect = "0";
            Assert.AreEqual(expect, Numbers.Multiply_fraction(frac1, frac2));
        }
        //Test for method Divide_fraction
        [Test]
        public void Test_Divide_fraction()
        {
            var frac1 = "3/4";
            var frac2 = "3/9";
            var expect = "9/4";
            Assert.AreEqual(expect, Numbers.Divide_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Divide_fraction_minus()
        {
            var frac1 = "-3/7";
            var frac2 = "3/5";
            var expect = "-5/7";
            Assert.AreEqual(expect, Numbers.Divide_fraction(frac1, frac2));
        }
        [Test]
        public void Test_Divide_fraction_zero()
        {
            var frac1 = "0/7";
            var frac2 = "0/4";
            var expect = "0";
            Assert.AreEqual(expect, Numbers.Divide_fraction(frac1, frac2));
        }
        //Test for method Decimal_fraction
        [Test]
        public void Test_Decimal_fraction()
        {
            var numb = "1,66";
            var expect = "83/50";
            Assert.AreEqual(expect, Numbers.Decimal_fraction(numb));
        }
        [Test]
        public void Test_Decimal_fraction_random_number()
        {
            var numb = "34,56";
            var expect = "864/25";
            Assert.AreEqual(expect, Numbers.Decimal_fraction(numb));
        }
        [Test]
        public void Test_Decimal_fraction_bignumber()
        {
            var numb = "3445,5689";
            var expect = "34455689/10000";
            Assert.AreEqual(expect, Numbers.Decimal_fraction(numb));
        }
        // Test for method Output_number 
        [Test]
        public void Test_Output_numbers()
        {
            var fraction = "34/45";
            var list_expect = new List<int>() { 34, 45 };
            Assert.AreEqual(list_expect, Numbers.Output_numbers(fraction));
        }
        [Test]
        public void Test_Output_numbers_minus()
        {
            var fraction = "-4/5";
            var list_expect = new List<int>() { -4, 5 };
            Assert.AreEqual(list_expect, Numbers.Output_numbers(fraction));
        }
        [Test]
        public void Test_Output_numbers_large_numbers()
        {
            var fraction = "34455/45567";
            var list_expect = new List<int>() { 34455, 45567 };
            Assert.AreEqual(list_expect, Numbers.Output_numbers(fraction));
        }
        //Test for method Intermittent_fraction 
        [Test]
        public void Test_Intermittent_fraction()
        {
            var fraction = "1/3";
            var expect = "0,(3)";
            Assert.AreEqual(expect, Numbers.Intermittent_fraction(fraction));
        }
        [Test]
        public void Test_Intermittent_fraction_denumerator()
        {
            var fraction = "46/89";
            var expect = "0,(51685393258426966292134831460674157303370786)";
            Assert.AreEqual(expect, Numbers.Intermittent_fraction(fraction));
        }
        [Test]
        public void Test_Intermittent_fraction_numerator()
        {
            var fraction = "68/9";
            var expect = "7,(5)";
            Assert.AreEqual(expect, Numbers.Intermittent_fraction(fraction));
        }
        //Test for method Ordinary_fraction
        [Test]
        public void Test_Ordinary_fraction_simple_number()
        {
            var fraction = "4,5(6)";
            var expect = "137/30";
            Assert.AreEqual(expect, Numbers.Ordinary_fraction(fraction));
        }
        [Test]
        public void Test_Ordinary_fraction_long_number()
        {
            var fraction = "467,556(62)";
            var expect = "23144053/49500";
            Assert.AreEqual(expect, Numbers.Ordinary_fraction(fraction));
        }
        [Test]
        public void Test_Ordinary_fraction_not_intermittent()
        {
            var fraction = "2,4";
            var expect = "����� �� �������� �������������";
            Assert.AreEqual(expect, Numbers.Ordinary_fraction(fraction));
        }
        [Test]
        public void Test_Ordinary_fraction_near_bracket()
        {
            var fraction = "2,(4)";
            var expect = "22/9";
            Assert.AreEqual(expect, Numbers.Ordinary_fraction(fraction));
        }
    }
}