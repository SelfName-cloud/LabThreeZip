﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ЛР3
{
    public class Rational_numbers
    {

        public string Input_numbers(int numerator, int denumerator)
        {
            if (numerator == 0 || denumerator== 0)
            {
                return 0.ToString();
            }
            else
            {
                return numerator.ToString() + '/' + denumerator.ToString();
            }
        }
        public List<int> Output_numbers(string fraction)
        {
            var list = new List<int>();
            var split_fraction = fraction.Split('/');
            list.Add(int.Parse(split_fraction[0]));
            list.Add(int.Parse(split_fraction[1]));
            return list;

        }

        public int Evklid_number(int numerator, int denumerator)
        {
            if (numerator < 0 )
            {
                numerator = numerator * -1;
                
            }
            if (denumerator < 0)
            {
                denumerator = denumerator * -1;
            }
            while(numerator != denumerator)
            {
                if(numerator > denumerator)
                {
                    numerator = numerator - denumerator;
                }
                else
                {
                    denumerator = denumerator - numerator;
                }
            }
         return numerator;

        }

        public string Plus_fraction(string ord_frac1, string ord_frac2)
        {
            Rational_numbers Numb = new Rational_numbers();
            var split_ord_frac1 = ord_frac1.Split('/');
            var split_ord_frac2 = ord_frac2.Split('/');
            var new_denumerator = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[1]);
            var new_numerator_ord_frac1 = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[0]);
            var new_numerator_ord_frac2 = int.Parse(split_ord_frac2[1]) * int.Parse(split_ord_frac1[0]);
            var new_numerator = new_numerator_ord_frac1 + new_numerator_ord_frac2;
            var Evklid_number = Numb.Evklid_number(new_numerator, new_denumerator);
            if (Evklid_number == 0)
            {
                return "0";
            }
            var reduced_numerator = new_numerator / Evklid_number;
            var reduced_denumerator = new_denumerator / Evklid_number;
            return reduced_numerator.ToString() + '/' + reduced_denumerator.ToString();
        }
        public string Minus_fraction(string ord_frac1, string ord_frac2)
        {
            Rational_numbers Numb = new Rational_numbers();
            var split_ord_frac1 = ord_frac1.Split('/');
            var split_ord_frac2 = ord_frac2.Split('/');
            var new_denumerator = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[1]);
            var new_numerator_ord_frac1 = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[0]);
            var new_numerator_ord_frac2 = int.Parse(split_ord_frac2[1]) * int.Parse(split_ord_frac1[0]);
            var new_numerator =new_numerator_ord_frac2 - new_numerator_ord_frac1;
            var Evklid_number = Numb.Evklid_number(new_numerator, new_denumerator);
            if (Evklid_number == 0)
            {
                return "0";
            }
            var reduced_numerator = new_numerator / Evklid_number;
            var reduced_denumerator = new_denumerator / Evklid_number;
            return reduced_numerator.ToString() + '/' + reduced_denumerator.ToString();
        }
        
        public string Multiply_fraction(string ord_frac1, string ord_frac2)
        {
            Rational_numbers Numb = new Rational_numbers();
            var split_ord_frac1 = ord_frac1.Split('/');
            var split_ord_frac2 = ord_frac2.Split('/');
            var new_numerator = int.Parse(split_ord_frac1[0]) * int.Parse(split_ord_frac2[0]);
            var new_denumerator = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[1]);
            if(new_numerator == 0)
            {
                return "0";
            }
            if (new_denumerator == 0)
            {
                return "Деление на ноль";
            }
            var Evklid_number = Numb.Evklid_number(new_numerator, new_denumerator);
            if (Evklid_number == 0)
            {
                return "0";
            }
            var reduced_numerator = new_numerator / Evklid_number;
            var reduced_denumerator = new_denumerator / Evklid_number;
            return reduced_numerator.ToString() + '/' + reduced_denumerator.ToString();



        }

        public string Divide_fraction(string ord_frac1, string ord_frac2)
        {
            Rational_numbers Numb = new Rational_numbers();
            var split_ord_frac1 = ord_frac1.Split('/');
            var split_ord_frac2 = ord_frac2.Split('/');
            var new_numerator = int.Parse(split_ord_frac1[0]) * int.Parse(split_ord_frac2[1]);
            var new_denumerator = int.Parse(split_ord_frac1[1]) * int.Parse(split_ord_frac2[0]);
            var Evklid_number = Numb.Evklid_number(new_numerator, new_denumerator);
            if (Evklid_number == 0)
            {
                return "0";
            }
            var reduced_numerator = new_numerator / Evklid_number;
            var reduced_denumerator = new_denumerator / Evklid_number;
            return reduced_numerator.ToString() + '/' + reduced_denumerator.ToString();
        }

        
        public string Intermittent_fraction(string ordinary_fraction)
        {
            StringBuilder sb = new StringBuilder();
            var split_ord_fraction = ordinary_fraction.Split('/');
            var numerator = int.Parse(split_ord_fraction[0]);
            var denumerator = int.Parse(split_ord_fraction[1]);
            var inter_fraction = (double)(numerator) / (double)(denumerator);
            int dev = numerator /denumerator;
            if (numerator < 1)
            {
                return "Делитель меньше 1";
            }
            else if(numerator == denumerator)
            {
                sb.Append(dev.ToString());
            }
            else if(numerator > denumerator)
            {
                double rest = inter_fraction - numerator / denumerator;
                sb.Append(dev.ToString());
                if(rest > 0)
                {
                    numerator -= dev * denumerator;
                    sb.Append("," + GetFraction(numerator, denumerator));
                }
            }
            else if (denumerator % 2 == 0 || denumerator % 5 == 0)
            {
                sb.Append(inter_fraction.ToString());
            }
            else
            {
                sb.Append(dev.ToString() + "," + GetFraction(numerator, denumerator));


            }
            return sb.ToString();


        }
        public string GetFraction(int numerator, int denumerator)
        {
            int[] digits = new int[denumerator];

            int k = 0, n = numerator;
            do
            {
                n *= 10;
                digits[k++] = n / denumerator;
                n = n % denumerator;
            }
            while (n != numerator);

            int[] period = new int[k];

            for (n = 0; n < k; ++n)
            {
                period[n] = digits[n];
            }

            StringBuilder s = new StringBuilder();

            if (period.Length > 0)
            {
                s.Append("(");
                for (int i = 0; i <= period.Length - 1; i++)
                {
                    s.Append(period[i]);
                }
                s.Append(")");
            }

            return s.ToString();

        }
        public string Decimal_fraction(string inter_fraction)
        {
            var rat_numb = new Rational_numbers();
            var split_inter_fraction = inter_fraction.Split(',');
            var denumerator = "1";
            for(int i = 0; i < split_inter_fraction[1].Length; i++)
            {
                denumerator += '0';
            }
            var numerator = int.Parse(split_inter_fraction[0]) * int.Parse(denumerator) + int.Parse(split_inter_fraction[1]);
            var numb_nod = rat_numb.Evklid_number(numerator, int.Parse(denumerator));
            var new_numerator = numerator / numb_nod;
            var new_denumerator = int.Parse(denumerator) / numb_nod;
            return new_numerator.ToString() + '/' + new_denumerator.ToString();
        }
        
        public string Ordinary_fraction(string fraction)
        {
            var rat_numb = new Rational_numbers();
            if (!fraction.Contains('('))
            {
                return "Дробь не является периодической";
            }
            
            var split_fraction = fraction.Split(new char[] {'.', ','});
            if (split_fraction[1][0] == '(')
            {
                var whole_part = int.Parse(split_fraction[0]);
                var fractional_part = split_fraction[1];
                var count_nine = "";
                var inside_bracket = fractional_part.Replace('(', ' ').Replace(')', ' ').Trim();
                for (var i = 0; i < inside_bracket.Length; i++)
                {
                    count_nine += "9";
                }
                var numerator = int.Parse(count_nine) * whole_part + int.Parse(inside_bracket);
                var denumerator = int.Parse(count_nine);
                var Evklid_number = rat_numb.Evklid_number(numerator, denumerator);
                if (Evklid_number == 0)
                {
                    return 0.ToString();
                }
                var new_numerator = numerator / Evklid_number;
                var new_denumerator = denumerator / Evklid_number;
                return new_numerator.ToString() + '/' + new_denumerator.ToString();

            }
            else
            {
                var whole_part = int.Parse(split_fraction[0]);
                var fractional_part = split_fraction[1];
                var split_fractional_part = fractional_part.Split('(');
                var before_bracket = split_fractional_part[0];
                var inside_bracket = split_fractional_part[1].Replace(')', ' ').Trim();
                var count_nine = "";
                var count_zero = "";
                for(var i = 0; i < inside_bracket.Length; i++)
                {
                    count_nine += "9";
                }
                for(var j = 0; j < before_bracket.Length; j++)
                {
                    count_zero += "0";
                }
                var denumerator = int.Parse(count_nine + count_zero);
                var numerator = ((int.Parse(before_bracket + inside_bracket) - int.Parse(before_bracket)) + whole_part * denumerator);
                var Evklid_number = rat_numb.Evklid_number(numerator, denumerator);
                if(Evklid_number == 0)
                {
                    return "0";
                }
                var new_numerator = numerator / Evklid_number;
                var new_denumerator = denumerator / Evklid_number;
            
                return new_numerator.ToString() + '/' + new_denumerator.ToString();

            }
            
        }
    }
}
