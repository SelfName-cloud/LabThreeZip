﻿using System;
using ЛР3;

namespace ЛР3
{
    class Program
    {
        static void Main(string[] args)
        {

            string first_fraction="";
            string second_fraction="";
            var numb = new ЛР3.Rational_numbers();
            Console.WriteLine("Выберите какие операции необхадимо применить к обыкновенным дробям: \n" +
                "1)Чтобы сложить нажмите (1)\n" + 
                "2)Чтобы вычесть нажмите (2)\n" + 
                "3)Чтобы умножить нажмите (3)\n" + 
                "4)Чтобы разделить нажмите (4)\n" + 
                "5)Чтобы найти НОД для числителя и знаменателя дроби нажмите (5)\n" + 
                "6)Чтобы перевести обыкновенную дробь в периодическую нажмите (6)\n" + 
                "7)Чтобы перевести из десятичной дроби в обыкновенную нажмите (7)\n" +
                "8)Чтобы перевести периодической дроби в обыкновенную нажмите (8)\n"
                );
            
            var input_user = int.Parse(Console.ReadLine());

            if (input_user == 1 || input_user == 2 || input_user == 3 || input_user == 4)
            {
                Console.WriteLine("Введите првую дробь:");
                first_fraction = Console.ReadLine();
                Console.WriteLine("Введите вторую дробь:");
                second_fraction = Console.ReadLine();

            }
            if(input_user == 1)
            {
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Plus_fraction(first_fraction, second_fraction));
               // Console.ReadKey();
            }
            else if(input_user == 2)
            {

                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Minus_fraction(first_fraction, second_fraction));
               // Console.ReadKey();
            }
            else if (input_user == 3)
            {
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Multiply_fraction(first_fraction, second_fraction));
               // Console.ReadKey();
            }
            else if (input_user == 4)
            {
                Console.WriteLine("Ответ:");
                Console.WriteLine( numb.Divide_fraction(first_fraction, second_fraction));
               // Console.ReadKey();
            }
            else if (input_user == 5)
            {
                Console.WriteLine("Введите числитель дроби");
                var frac_first = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите знаменатель дроби");
                var frac_second = int.Parse(Console.ReadLine());
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Evklid_number(frac_first, frac_second));
               // Console.ReadKey();
            }
            else if (input_user == 6)
            {
                Console.WriteLine("Введите дробь, которую необходимо преобразовать в периодическую:");
                var input_frac = Console.ReadLine();
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Intermittent_fraction(input_frac));
               // Console.ReadKey();
            }
            else if (input_user == 7)
            {
                Console.WriteLine("Введите дробь, которую необходимо преобразовать в обыкновеную:");
                var input_frac = Console.ReadLine();
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Decimal_fraction(input_frac));
                //Console.ReadLine();
            }
            else if (input_user == 8)
            {
                Console.WriteLine("Введите дробь, которую нужно преобразовать в обыкновенную: ");
                var input_frac = Console.ReadLine();
                Console.WriteLine("Ответ:");
                Console.WriteLine(numb.Ordinary_fraction(input_frac));
                //Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Запустите программу заново");
            }
            Console.ReadLine();

            
        }
    }
}
